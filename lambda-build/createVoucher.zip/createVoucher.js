"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var pg_1 = require("pg");
var headers = {
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST",
};
var handler = function () {
    var args_1 = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args_1[_i] = arguments[_i];
    }
    return __awaiter(void 0, __spreadArray([], args_1, true), void 0, function (event) {
        var client, method, body, eventId, providerId, uiType, expirationDate, valueRaw, promoItemRaw, dbType, value, promoItem, n, n, existingSql, existingRes, voucherId, insertSql, params, result, err_1, _a;
        var _b, _c, _d, _e, _f;
        if (event === void 0) { event = {}; }
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    client = null;
                    _g.label = 1;
                case 1:
                    _g.trys.push([1, 8, , 14]);
                    method = event.httpMethod || ((_c = (_b = event.requestContext) === null || _b === void 0 ? void 0 : _b.http) === null || _c === void 0 ? void 0 : _c.method);
                    if (method === "OPTIONS") {
                        return [2 /*return*/, { statusCode: 200, headers: headers, body: "" }];
                    }
                    if (method !== "POST") {
                        return [2 /*return*/, {
                                statusCode: 405,
                                headers: headers,
                                body: JSON.stringify({ error: "Method not allowed" }),
                            }];
                    }
                    body = event.body ? JSON.parse(event.body) : {};
                    eventId = String((_d = body.eventId) !== null && _d !== void 0 ? _d : "").trim();
                    providerId = String((_e = body.providerId) !== null && _e !== void 0 ? _e : "").trim();
                    uiType = String((_f = body.type) !== null && _f !== void 0 ? _f : "").trim().toUpperCase();
                    expirationDate = body.expirationDate ? String(body.expirationDate) : null;
                    valueRaw = body.value;
                    promoItemRaw = body.promoItem;
                    if (!eventId || !providerId || !uiType) {
                        return [2 /*return*/, {
                                statusCode: 400,
                                headers: headers,
                                body: JSON.stringify({ error: "Missing eventId, providerId, or type" }),
                            }];
                    }
                    if (!["P", "A", "F"].includes(uiType)) {
                        return [2 /*return*/, {
                                statusCode: 400,
                                headers: headers,
                                body: JSON.stringify({ error: "Invalid voucher type. Use P, A, or F." }),
                            }];
                    }
                    dbType = uiType === "P" ? "A" :
                        uiType === "A" ? "B" :
                            "C";
                    value = 0;
                    promoItem = null;
                    if (uiType === "P") {
                        n = Number(valueRaw);
                        if (!Number.isFinite(n) || n <= 0 || n > 100) {
                            return [2 /*return*/, {
                                    statusCode: 400,
                                    headers: headers,
                                    body: JSON.stringify({ error: "Percent discount must be between 1 and 100" }),
                                }];
                        }
                        value = n;
                    }
                    if (uiType === "A") {
                        n = Number(valueRaw);
                        if (!Number.isFinite(n) || n <= 0) {
                            return [2 /*return*/, {
                                    statusCode: 400,
                                    headers: headers,
                                    body: JSON.stringify({ error: "Amount discount must be greater than 0" }),
                                }];
                        }
                        value = n;
                    }
                    if (uiType === "F") {
                        if (typeof promoItemRaw !== "string" || promoItemRaw.trim() === "") {
                            return [2 /*return*/, {
                                    statusCode: 400,
                                    headers: headers,
                                    body: JSON.stringify({ error: "promoItem is required for free-item vouchers" }),
                                }];
                        }
                        promoItem = promoItemRaw.trim();
                        value = 0;
                    }
                    // ---------- DB ----------
                    client = new pg_1.Client({
                        host: process.env.DB_HOST,
                        user: process.env.DB_USER,
                        password: process.env.DB_PASS,
                        database: process.env.DB_NAME,
                        port: parseInt(process.env.DB_PORT || "5432", 10),
                        ssl: { rejectUnauthorized: false },
                    });
                    return [4 /*yield*/, client.connect()];
                case 2:
                    _g.sent();
                    existingSql = "\n      SELECT\n        voucher_id,\n        event_id,\n        provider_id,\n        type,\n        value,\n        expiration_date,\n        status,\n        promo_item,\n        created_at\n      FROM vouchers\n      WHERE provider_id = $1\n        AND event_id = $2\n      ORDER BY created_at DESC\n      LIMIT 1;\n    ";
                    return [4 /*yield*/, client.query(existingSql, [providerId, eventId])];
                case 3:
                    existingRes = _g.sent();
                    if (!(existingRes.rowCount && existingRes.rows[0])) return [3 /*break*/, 5];
                    // If you ever want to "re-activate" after redeemed/expired, you could do it here.
                    // But based on your requirement: DO NOT allow sign up again.
                    return [4 /*yield*/, client.end()];
                case 4:
                    // If you ever want to "re-activate" after redeemed/expired, you could do it here.
                    // But based on your requirement: DO NOT allow sign up again.
                    _g.sent();
                    client = null;
                    return [2 /*return*/, {
                            statusCode: 200,
                            headers: headers,
                            body: JSON.stringify({
                                voucher: existingRes.rows[0],
                                alreadySignedUp: true,
                            }),
                        }];
                case 5:
                    voucherId = "V-".concat(Date.now(), "-").concat(Math.random().toString(16).slice(2, 8));
                    insertSql = "\n      INSERT INTO vouchers (\n        voucher_id,\n        event_id,\n        provider_id,\n        type,\n        value,\n        expiration_date,\n        status,\n        promo_item\n      )\n      VALUES ($1,$2,$3,$4,$5,$6,'active',$7)\n      RETURNING\n        voucher_id,\n        event_id,\n        provider_id,\n        type,\n        value,\n        expiration_date,\n        status,\n        promo_item,\n        created_at;\n    ";
                    params = [
                        voucherId,
                        eventId,
                        providerId,
                        dbType,
                        value,
                        expirationDate,
                        promoItem,
                    ];
                    return [4 /*yield*/, client.query(insertSql, params)];
                case 6:
                    result = _g.sent();
                    return [4 /*yield*/, client.end()];
                case 7:
                    _g.sent();
                    client = null;
                    return [2 /*return*/, {
                            statusCode: 200,
                            headers: headers,
                            body: JSON.stringify({ voucher: result.rows[0], alreadySignedUp: false }),
                        }];
                case 8:
                    err_1 = _g.sent();
                    console.error("createVoucher error:", err_1);
                    _g.label = 9;
                case 9:
                    _g.trys.push([9, 12, , 13]);
                    if (!client) return [3 /*break*/, 11];
                    return [4 /*yield*/, client.end()];
                case 10:
                    _g.sent();
                    _g.label = 11;
                case 11: return [3 /*break*/, 13];
                case 12:
                    _a = _g.sent();
                    return [3 /*break*/, 13];
                case 13: return [2 /*return*/, {
                        statusCode: 500,
                        headers: headers,
                        body: JSON.stringify({ error: "Failed to create voucher" }),
                    }];
                case 14: return [2 /*return*/];
            }
        });
    });
};
exports.handler = handler;
